"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Menu, X } from "lucide-react"

export default function NavigationMenu() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  return (
    <header className="w-full">
      {/* Mobile Menu Toggle */}
      <div className="md:hidden fixed top-4 left-4 z-50">
        <input type="checkbox" id="menu-toggle" className="hidden" checked={isMenuOpen} onChange={toggleMenu} />
        <label htmlFor="menu-toggle" className="block cursor-pointer">
          <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-md">
            {isMenuOpen ? <X className="w-6 h-6 text-black" /> : <Menu className="w-6 h-6 text-black" />}
          </div>
        </label>
      </div>

      {/* Mobile Navigation Menu */}
      <div
        className={`fixed inset-0 bg-black/95 z-40 flex items-center justify-center transition-transform duration-300 md:hidden ${
          isMenuOpen ? "transform-none" : "translate-x-full"
        }`}
      >
        <ul className="text-center space-y-6">
          <li>
            <Link
              href="/"
              className="text-white font-cormorant text-2xl hover:text-[#f0d9c8]"
              onClick={() => setIsMenuOpen(false)}
            >
              Startseite
            </Link>
          </li>
          <li>
            <Link
              href="/wedding"
              className="text-white font-cormorant text-2xl hover:text-[#f0d9c8]"
              onClick={() => setIsMenuOpen(false)}
            >
              Hochzeitsfotos
            </Link>
          </li>
          <li>
            <Link
              href="/kids"
              className="text-white font-cormorant text-2xl hover:text-[#f0d9c8]"
              onClick={() => setIsMenuOpen(false)}
            >
              Kinderfotografie
            </Link>
          </li>
          <li>
            <Link
              href="/family"
              className="text-white font-cormorant text-2xl hover:text-[#f0d9c8]"
              onClick={() => setIsMenuOpen(false)}
            >
              Familienfotos
            </Link>
          </li>
          <li>
            <Link
              href="/couple"
              className="text-white font-cormorant text-2xl hover:text-[#f0d9c8]"
              onClick={() => setIsMenuOpen(false)}
            >
              Paarfotos
            </Link>
          </li>
          <li>
            <Link
              href="/maternity"
              className="text-white font-cormorant text-2xl hover:text-[#f0d9c8]"
              onClick={() => setIsMenuOpen(false)}
            >
              Babybauch
            </Link>
          </li>
          <li>
            <Link
              href="/portrait"
              className="text-white font-cormorant text-2xl hover:text-[#f0d9c8]"
              onClick={() => setIsMenuOpen(false)}
            >
              Porträts
            </Link>
          </li>
        </ul>
      </div>

      {/* Desktop Header */}
      <div className="hidden md:block py-6 px-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          {/* Logo */}
          <div className="w-64">
            <Link href="/">
              <Image
                src="/icons/photo_grapgybyannika.png"
                alt="Photography by Annika"
                width={240}
                height={80}
                className="object-contain"
              />
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav>
            <ul className="flex space-x-6">
              <li>
                <Link href="/" className="font-cormorant text-lg hover:text-gray-700 transition-colors">
                  Startseite
                </Link>
              </li>
              <li>
                <Link href="/wedding" className="font-cormorant text-lg hover:text-gray-700 transition-colors">
                  Hochzeitsfotos
                </Link>
              </li>
              <li>
                <Link href="/kids" className="font-cormorant text-lg hover:text-gray-700 transition-colors">
                  Kinderfotografie
                </Link>
              </li>
              <li>
                <Link href="/family" className="font-cormorant text-lg hover:text-gray-700 transition-colors">
                  Familienfotos
                </Link>
              </li>
              <li>
                <Link href="/couple" className="font-cormorant text-lg hover:text-gray-700 transition-colors">
                  Paarfotos
                </Link>
              </li>
              <li>
                <Link href="/maternity" className="font-cormorant text-lg hover:text-gray-700 transition-colors">
                  Babybauch
                </Link>
              </li>
              <li>
                <Link href="/portrait" className="font-cormorant text-lg hover:text-gray-700 transition-colors">
                  Porträts
                </Link>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </header>
  )
}
